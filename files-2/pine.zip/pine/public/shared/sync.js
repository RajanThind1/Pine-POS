/**
 * Pine POS — shared real-time sync client
 * --------------------------------------------------------------
 * Used by all three frontends (POS terminal, handheld, KDS).
 *
 * Pattern: the server holds canonical "shared" state (everything
 * except per-device session info like currentStaff/view/viewParams).
 * Each frontend keeps its own STATE object that's a superset of this
 * (it adds session fields locally). After a local mutation, the
 * frontend calls PineSync.push(STATE) to broadcast the shared slices;
 * incoming updates from other devices arrive via onUpdate(shared).
 */
(function (global) {
  const SHARED_KEYS = [
    'restaurant', 'staff', 'menu', 'modifierGroups', 'tables', 'orders',
    'completedOrders', 'inventory', 'customers', 'tipOuts', 'notifications',
    'giftCards', 'vouchers', 'settlementBatches',
    'nextUid', 'nextOrderId',
  ];

  let socket = null;
  let pushTimer = null;
  let pendingState = null;

  const PineSync = {
    SHARED_KEYS,

    /** Fetch the full shared state from the server (initial load). */
    async loadState() {
      const res = await fetch('/api/state');
      if (!res.ok) throw new Error('Failed to load state from server');
      return res.json();
    },

    /** PIN login — also clocks the staff member in on the server. */
    async login(pin) {
      const res = await fetch('/api/login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ pin }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || 'Login failed');
      return data.staff;
    },

    /**
     * Connect to the real-time channel. `onUpdate(sharedSlice)` is
     * called whenever another device changes shared state, and once
     * immediately on connect with the full canonical state.
     */
    connect(onUpdate, opts = {}) {
      socket = io();
      socket.on('state:update', (shared) => onUpdate(shared));
      socket.on('connect', () => { if (opts.onConnect) opts.onConnect(); });
      socket.on('disconnect', () => { if (opts.onDisconnect) opts.onDisconnect(); });
      return socket;
    },

    /**
     * Push the shared slices of `fullState` to the server (debounced
     * ~150ms so rapid clicks coalesce into one sync message).
     */
    push(fullState) {
      pendingState = fullState;
      if (pushTimer) clearTimeout(pushTimer);
      pushTimer = setTimeout(() => {
        if (!socket || !pendingState) return;
        const shared = {};
        SHARED_KEYS.forEach(k => { shared[k] = pendingState[k]; });
        socket.emit('state:update', shared);
        pendingState = null;
        pushTimer = null;
      }, 150);
    },

    /** Merge an incoming shared slice into a local STATE object in place. */
    merge(localState, shared) {
      Object.assign(localState, shared);
      // currentStaff is a reference into staff[] — re-resolve it so it
      // reflects fresh data (e.g. clockedIn changed on another device).
      if (localState.currentStaff) {
        const fresh = localState.staff.find(s => s.id === localState.currentStaff.id);
        if (fresh) localState.currentStaff = fresh;
      }
    },

    get connected() { return !!(socket && socket.connected); },
  };

  global.PineSync = PineSync;
})(window);
