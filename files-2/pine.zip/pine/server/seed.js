/**
 * Seed data + seeding logic for Pine POS.
 * Ported from the original single-file frontend STATE object so the
 * backend becomes the single source of truth for all three frontends
 * (POS terminal, handheld, KDS).
 */

const seedState = {
  restaurant:{
    name:'The Riverside Bistro',
    address:'482 Harbor St, Seattle, WA 98101',
    phone:'(206) 555-0148',
    taxRate:0.0925,
    receiptHeader:'The Riverside Bistro',
    receiptFooter:'Thank you for dining with us — see you again soon!',
    tipPresets:[0.18,0.20,0.25],
    sections:['Main Dining','Patio','Bar'],
  },
  currentStaff:null,
  view:'dashboard',
  notifications:[
    {id:1, text:'Low stock alert: Salmon Fillet below par level', time:Date.now()-1000*60*22, type:'warning'},
    {id:2, text:'Online order #1049 received — Takeout', time:Date.now()-1000*60*9, type:'info'},
    {id:3, text:'Table 7 check has been open for 55 minutes', time:Date.now()-1000*60*3, type:'warning'},
  ],
  nextUid:1000,
  nextOrderId:1050,

  staff:[
    {id:1, name:'Maria Lopez', pin:'1234', role:'Manager', color:'#1B6FE0', hourlyRate:26, clockedIn:true, clockInTime:Date.now()-1000*60*210, permissions:['all']},
    {id:2, name:'James Chen', pin:'2222', role:'Server', color:'#0FB6AC', hourlyRate:16, clockedIn:true, clockInTime:Date.now()-1000*60*180, permissions:['pos','tables']},
    {id:3, name:'Aisha Patel', pin:'3333', role:'Server', color:'#E0922A', hourlyRate:16, clockedIn:true, clockInTime:Date.now()-1000*60*120, permissions:['pos','tables']},
    {id:4, name:'Tom Reilly', pin:'4444', role:'Cook', color:'#E0473F', hourlyRate:19, clockedIn:true, clockInTime:Date.now()-1000*60*240, permissions:['kitchen']},
    {id:5, name:'Sara Kim', pin:'5555', role:'Host', color:'#7C5CFC', hourlyRate:15, clockedIn:false, clockInTime:null, permissions:['tables']},
    {id:6, name:'Diego Ruiz', pin:'6666', role:'Bartender', color:'#1F9D55', hourlyRate:18, clockedIn:true, clockInTime:Date.now()-1000*60*150, permissions:['pos','tables']},
    {id:7, name:'Priya Nair', pin:'7777', role:'Server', color:'#E0473F', hourlyRate:16, clockedIn:false, clockInTime:null, permissions:['pos','tables']},
    {id:8, name:'Owen Brooks', pin:'8888', role:'Cook', color:'#1452AD', hourlyRate:19, clockedIn:false, clockInTime:null, permissions:['kitchen']},
  ],

  modifierGroups:{
    addons:{name:'Add-ons', type:'multi', required:false, options:[
      {name:'Extra Cheese', price:1.0},{name:'Bacon', price:1.5},{name:'Avocado', price:1.5},{name:'Fried Egg', price:1.0},{name:'Sauteed Mushrooms', price:1.0}
    ]},
    temp:{name:'Temperature', type:'single', required:true, options:[
      {name:'Rare', price:0},{name:'Medium Rare', price:0},{name:'Medium', price:0},{name:'Medium Well', price:0},{name:'Well Done', price:0}
    ]},
    dressing:{name:'Dressing', type:'single', required:true, options:[
      {name:'Ranch', price:0},{name:'Caesar', price:0},{name:'Balsamic Vinaigrette', price:0},{name:'Blue Cheese', price:0},{name:'Oil & Vinegar', price:0}
    ]},
    pizzaSize:{name:'Size', type:'single', required:true, options:[
      {name:'10" Personal', price:0},{name:'14" Medium', price:4},{name:'18" Large', price:8}
    ]},
    spice:{name:'Spice Level', type:'single', required:false, options:[
      {name:'Mild', price:0},{name:'Medium', price:0},{name:'Hot', price:0},{name:'Extra Hot', price:0}
    ]},
    side:{name:'Choice of Side', type:'single', required:true, options:[
      {name:'French Fries', price:0},{name:'Side Salad', price:0},{name:'Soup of the Day', price:1.5},{name:'Sauteed Vegetables', price:0},{name:'Mashed Potatoes', price:0}
    ]},
    bread:{name:'Bread', type:'single', required:true, options:[
      {name:'Brioche Bun', price:0},{name:'Multigrain', price:0},{name:'Gluten-Free', price:1.5},{name:'Lettuce Wrap', price:0}
    ]},
    espresso:{name:'Milk Choice', type:'single', required:false, options:[
      {name:'Whole Milk', price:0},{name:'Oat Milk', price:0.7},{name:'Almond Milk', price:0.7},{name:'Skim Milk', price:0}
    ]},
  },

  menu:{
    categories:[
      {id:'starters', name:'Starters', icon:'🥗', station:'Cold Line'},
      {id:'salads', name:'Salads', icon:'🥬', station:'Cold Line'},
      {id:'sandwiches', name:'Sandwiches', icon:'🥪', station:'Grill'},
      {id:'entrees', name:'Entrées', icon:'🍽️', station:'Grill'},
      {id:'pizza', name:'Pizza', icon:'🍕', station:'Pizza Oven'},
      {id:'desserts', name:'Desserts', icon:'🍰', station:'Pastry'},
      {id:'beverages', name:'Beverages', icon:'🥤', station:'Bar'},
      {id:'cocktails', name:'Cocktails & Wine', icon:'🍷', station:'Bar'},
    ],
    items:[
      {id:1, category:'starters', name:'Crispy Calamari', price:13.5, desc:'Lightly fried, served with lemon aioli', icon:'🦑', available:true, modGroups:['spice'], cost:3.8},
      {id:2, category:'starters', name:'Loaded Nachos', price:12.0, desc:'Cheddar, jalapeños, pico, sour cream', icon:'🧀', available:true, modGroups:['addons','spice'], cost:3.1},
      {id:3, category:'starters', name:'Soup of the Day', price:7.5, desc:"Chef's daily selection, ask your server", icon:'🥣', available:true, modGroups:[], cost:1.9},
      {id:4, category:'starters', name:'Garlic Bread', price:6.5, desc:'Toasted baguette, herb butter, parmesan', icon:'🥖', available:true, modGroups:[], cost:1.4},
      {id:5, category:'starters', name:'Bruschetta Trio', price:10.0, desc:'Tomato basil, mushroom, white bean', icon:'🍅', available:false, modGroups:[], cost:2.6},

      {id:6, category:'salads', name:'Caesar Salad', price:11.0, desc:'Romaine, parmesan, croutons, caesar dressing', icon:'🥗', available:true, modGroups:['addons','dressing'], cost:2.4},
      {id:7, category:'salads', name:'Harvest Salad', price:12.5, desc:'Mixed greens, apple, candied pecans, goat cheese', icon:'🥬', available:true, modGroups:['addons','dressing'], cost:3.0},
      {id:8, category:'salads', name:'Grilled Chicken Cobb', price:14.5, desc:'Egg, bacon, avocado, blue cheese, tomato', icon:'🍗', available:true, modGroups:['dressing'], cost:4.2},

      {id:9, category:'sandwiches', name:'Classic Burger', price:14.5, desc:'Brioche bun, lettuce, tomato, house sauce', icon:'🍔', available:true, modGroups:['temp','addons','bread','side'], cost:4.6},
      {id:10, category:'sandwiches', name:'Crispy Chicken Sandwich', price:13.5, desc:'Buttermilk fried chicken, slaw, pickles', icon:'🍗', available:true, modGroups:['spice','addons','side'], cost:4.0},
      {id:11, category:'sandwiches', name:'Reuben', price:13.0, desc:'Pastrami, swiss, sauerkraut, russian dressing', icon:'🥪', available:true, modGroups:['side'], cost:4.3},
      {id:12, category:'sandwiches', name:'Veggie Melt', price:12.0, desc:'Roasted vegetables, provolone, pesto', icon:'🥪', available:true, modGroups:['side','bread'], cost:3.0},

      {id:13, category:'entrees', name:'Grilled Salmon', price:24.0, desc:'Lemon butter, seasonal vegetables', icon:'🐟', available:true, modGroups:['side'], cost:8.7},
      {id:14, category:'entrees', name:'8oz Sirloin Steak', price:27.5, desc:'Garlic herb butter, choice of side', icon:'🥩', available:true, modGroups:['temp','side'], cost:9.8},
      {id:15, category:'entrees', name:'Roast Chicken', price:19.5, desc:'Half chicken, jus, choice of side', icon:'🍗', available:true, modGroups:['side'], cost:5.4},
      {id:16, category:'entrees', name:'Wild Mushroom Risotto', price:18.0, desc:'Parmesan, white wine, truffle oil', icon:'🍚', available:true, modGroups:[], cost:4.0},
      {id:17, category:'entrees', name:'Fish & Chips', price:17.5, desc:'Beer-battered cod, tartar sauce, fries', icon:'🍟', available:true, modGroups:[], cost:5.0},

      {id:18, category:'pizza', name:'Margherita', price:14.0, desc:'San marzano tomato, fresh mozzarella, basil', icon:'🍕', available:true, modGroups:['pizzaSize'], cost:3.2},
      {id:19, category:'pizza', name:'Pepperoni', price:16.0, desc:'Mozzarella, pepperoni, tomato sauce', icon:'🍕', available:true, modGroups:['pizzaSize'], cost:3.9},
      {id:20, category:'pizza', name:'BBQ Chicken', price:17.0, desc:'Smoked gouda, red onion, cilantro', icon:'🍕', available:true, modGroups:['pizzaSize'], cost:4.3},
      {id:21, category:'pizza', name:'Veggie Supreme', price:15.5, desc:'Peppers, mushroom, olives, onion', icon:'🍕', available:true, modGroups:['pizzaSize'], cost:3.6},

      {id:22, category:'desserts', name:'New York Cheesecake', price:8.5, desc:'Graham crust, berry compote', icon:'🍰', available:true, modGroups:[], cost:1.9},
      {id:23, category:'desserts', name:'Molten Chocolate Cake', price:9.5, desc:'Warm cake, vanilla ice cream', icon:'🍫', available:true, modGroups:[], cost:2.2},
      {id:24, category:'desserts', name:'Crème Brûlée', price:8.0, desc:'Classic vanilla custard, caramelized sugar', icon:'🍮', available:true, modGroups:[], cost:1.7},

      {id:25, category:'beverages', name:'Fountain Soda', price:3.5, desc:'Free refills', icon:'🥤', available:true, modGroups:[], cost:0.4},
      {id:26, category:'beverages', name:'Fresh Lemonade', price:4.5, desc:'House-made, lightly sweet', icon:'🍋', available:true, modGroups:[], cost:0.8},
      {id:27, category:'beverages', name:'Iced Tea', price:3.5, desc:'Black tea, unsweet or sweet', icon:'🧊', available:true, modGroups:[], cost:0.4},
      {id:28, category:'beverages', name:'Espresso / Latte', price:4.5, desc:'Locally roasted beans', icon:'☕', available:true, modGroups:['espresso'], cost:1.0},

      {id:29, category:'cocktails', name:'Riverside Mule', price:12.0, desc:'Vodka, ginger beer, lime', icon:'🍹', available:true, modGroups:[], cost:3.0},
      {id:30, category:'cocktails', name:'Classic Margarita', price:12.5, desc:'Tequila, triple sec, lime', icon:'🍸', available:true, modGroups:[], cost:3.2},
      {id:31, category:'cocktails', name:'House Red / White', price:10.0, desc:'Ask your server for today\'s pour', icon:'🍷', available:true, modGroups:[], cost:2.8},
      {id:32, category:'cocktails', name:'Draft Beer', price:7.5, desc:'Rotating local taps', icon:'🍺', available:true, modGroups:[], cost:1.9},
    ],
  },

  tables:[
    {id:1, number:1, seats:2, shape:'round', section:'Main Dining', status:'available', x:10, y:18},
    {id:2, number:2, seats:2, shape:'round', section:'Main Dining', status:'available', x:30, y:18},
    {id:3, number:3, seats:4, shape:'square', section:'Main Dining', status:'available', x:54, y:16},
    {id:4, number:4, seats:4, shape:'square', section:'Main Dining', status:'available', x:80, y:16},
    {id:5, number:5, seats:6, shape:'rect', section:'Main Dining', status:'available', x:92, y:55},
    {id:6, number:6, seats:4, shape:'square', section:'Main Dining', status:'available', x:54, y:55},
    {id:7, number:7, seats:4, shape:'square', section:'Main Dining', status:'available', x:80, y:55},
    {id:8, number:8, seats:2, shape:'round', section:'Main Dining', status:'available', x:10, y:55},
    {id:9, number:9, seats:8, shape:'rect', section:'Main Dining', status:'available', x:30, y:85},
    {id:10, number:10, seats:4, shape:'square', section:'Patio', status:'available', x:20, y:25},
    {id:11, number:11, seats:4, shape:'square', section:'Patio', status:'available', x:50, y:25},
    {id:12, number:12, seats:2, shape:'round', section:'Patio', status:'available', x:80, y:25},
    {id:13, number:13, seats:6, shape:'rect', section:'Patio', status:'available', x:50, y:70},
    {id:14, number:'B1', seats:1, shape:'round', section:'Bar', status:'available', x:15, y:35},
    {id:15, number:'B2', seats:1, shape:'round', section:'Bar', status:'available', x:38, y:35},
    {id:16, number:'B3', seats:1, shape:'round', section:'Bar', status:'available', x:61, y:35},
    {id:17, number:'B4', seats:1, shape:'round', section:'Bar', status:'available', x:84, y:35},
  ],

  orders:{},          // active orders, keyed by order id
  completedOrders:[], // history for reports / dashboard
  tipOuts:[],         // {id, from, fromId, to, toId, amount, ts} — shift-end tip-outs to BOH staff

  inventory:[
    {id:1, name:'Salmon Fillet', unit:'lb', stock:6, par:15, cost:9.2, category:'Protein'},
    {id:2, name:'Sirloin Steak', unit:'lb', stock:18, par:20, cost:10.5, category:'Protein'},
    {id:3, name:'Chicken Breast', unit:'lb', stock:24, par:25, cost:3.6, category:'Protein'},
    {id:4, name:'Burger Patty', unit:'unit', stock:42, par:60, cost:2.1, category:'Protein'},
    {id:5, name:'Mozzarella', unit:'lb', stock:9, par:18, cost:4.4, category:'Dairy'},
    {id:6, name:'Romaine Lettuce', unit:'head', stock:14, par:20, cost:1.6, category:'Produce'},
    {id:7, name:'Tomatoes', unit:'lb', stock:11, par:15, cost:2.3, category:'Produce'},
    {id:8, name:'Avocado', unit:'unit', stock:5, par:24, cost:0.9, category:'Produce'},
    {id:9, name:'Pizza Dough', unit:'unit', stock:28, par:30, cost:1.1, category:'Dry Goods'},
    {id:10, name:'Russet Potatoes', unit:'lb', stock:40, par:40, cost:0.7, category:'Produce'},
    {id:11, name:'House Vodka', unit:'bottle', stock:7, par:8, cost:18.0, category:'Bar'},
    {id:12, name:'Tequila', unit:'bottle', stock:2, par:6, cost:24.0, category:'Bar'},
    {id:13, name:'Draft Beer Keg', unit:'keg', stock:1, par:3, cost:120.0, category:'Bar'},
    {id:14, name:'Coffee Beans', unit:'lb', stock:6, par:10, cost:8.5, category:'Dry Goods'},
    {id:15, name:'Heavy Cream', unit:'qt', stock:8, par:10, cost:3.2, category:'Dairy'},
  ],

  customers:[
    {id:1, name:'Ethan Brooks', phone:'(206) 555-0110', email:'ethan.b@example.com', address:'412 Pine St, Seattle, WA 98101', visits:14, points:340, totalSpent:842.50, since:'2024-02-12'},
    {id:2, name:'Sofia Martinez', phone:'(206) 555-0124', email:'sofia.m@example.com', address:'88 Riverside Dr, Apt 3B, Seattle, WA 98121', visits:22, points:610, totalSpent:1390.20, since:'2023-11-03'},
    {id:3, name:'Liam Walker', phone:'(206) 555-0188', email:'liam.w@example.com', address:'1500 Alaskan Way, Seattle, WA 98104', visits:5, points:90, totalSpent:215.00, since:'2025-04-21'},
    {id:4, name:'Grace Kim', phone:'(206) 555-0142', email:'grace.k@example.com', address:'2200 Westlake Ave, Unit 901, Seattle, WA 98121', visits:31, points:980, totalSpent:2110.75, since:'2023-06-18'},
    {id:5, name:'Noah Davis', phone:'(206) 555-0177', email:'noah.d@example.com', address:'733 Broadway E, Seattle, WA 98102', visits:2, points:25, totalSpent:78.40, since:'2026-05-02'},
    {id:6, name:'Olivia Bennett', phone:'(206) 555-0199', email:'olivia.b@example.com', address:'19 Harbor View Ln, Bainbridge Island, WA 98110', visits:9, points:215, totalSpent:498.10, since:'2024-09-09'},
    {id:7, name:'Marcus Lee', phone:'(206) 555-0163', email:'marcus.l@example.com', address:'5012 University Way NE, Seattle, WA 98105', visits:17, points:455, totalSpent:990.60, since:'2024-01-27'},
  ],

  /* ---- Back office: payments infrastructure ---- */
  giftCards:[
    {id:1, code:'GC-7H2K-9XQ4', initialAmount:100, balance:62.50, customerId:4, issuedBy:'Maria Lopez', ts:Date.now()-21*86400000, active:true,
      history:[{type:'issue', amount:100, ts:Date.now()-21*86400000, by:'Maria Lopez'}, {type:'redeem', amount:-37.50, ts:Date.now()-9*86400000, note:'Order #9188'}]},
    {id:2, code:'GC-3M8P-1RT6', initialAmount:50, balance:50, customerId:2, issuedBy:'Maria Lopez', ts:Date.now()-4*86400000, active:true,
      history:[{type:'issue', amount:50, ts:Date.now()-4*86400000, by:'Maria Lopez'}]},
  ],
  vouchers:[
    {id:1, code:'VCH-WELCOME25', amount:25, customerId:5, sentTo:'noah.d@example.com', sentBy:'Maria Lopez', ts:Date.now()-2*86400000, redeemed:false, note:'Service recovery — long wait on 6/19'},
  ],
  settlementBatches:[], // filled by buildCompletedOrders with one closed batch per past day
};



/* ---------- helpers ported from frontend (operate on a `state` object) ---------- */
let state; // module-level binding used by the helper closures below


function localUid(state){ return 'u'+(state.nextUid++); }

function findMenuItem(id){ return state.menu.items.find(i=>i.id===id); }
function findCategory(id){ return state.menu.categories.find(c=>c.id===id); }
function findModGroup(key){ return state.modifierGroups[key]; }

function buildOrderItem(menuId, qty, modSelections, notes, status, firedAgoMs){
  const mi = findMenuItem(menuId);
  let modPrice = 0;
  const mods = [];
  (modSelections||[]).forEach(sel=>{
    const grp = findModGroup(sel.group);
    (sel.choices||[sel.choice]).forEach(choiceName=>{
      const opt = grp.options.find(o=>o.name===choiceName);
      if(opt){ modPrice += opt.price; mods.push({group:grp.name, name:opt.name, price:opt.price}); }
    });
  });
  return {
    uid: localUid(state),
    menuItemId: menuId,
    name: mi.name,
    icon: mi.icon,
    basePrice: mi.price,
    modPrice,
    qty: qty||1,
    mods,
    notes: notes||'',
    station: findCategory(mi.category).station,
    status: status||'new', // new -> fired -> ready -> served
    firedAt: firedAgoMs!=null ? Date.now()-firedAgoMs : null,
  };
}
function lineTotal(item){ return (item.basePrice+item.modPrice)*item.qty; }
function orderTotals(order){
  const subtotal = order.items.reduce((s,it)=> s+lineTotal(it), 0);
  const discount = order.discount||0;
  const taxable = Math.max(0, subtotal-discount);
  const tax = taxable*state.restaurant.taxRate;
  const tip = order.tip||0;
  const total = taxable+tax+tip;
  return {subtotal, discount, tax, tip, total};
}
function getTable(id){ return state.tables.find(t=>t.id===id); }
function tableLabel(id){ const t=getTable(id); return t? t.number : ''; }
function getActiveOrderForTable(tableId){
  return Object.values(state.orders).find(o=>o.tableId===tableId && o.status==='open');
}
function getOrder(id){ return state.orders[id]; }
function countKitchenTickets(){
  return Object.values(state.orders).filter(o=>o.status==='open' && o.items.some(it=>it.status==='fired'||it.status==='ready')).length;
}
function countOpenChecks(){
  return Object.values(state.orders).filter(o=>o.status==='open').length;
}

/* ---- Seed: active orders ---- */
function seedActiveOrders(activeState){
  state = activeState;
  const mk=(tableId, server, guests, openedAgoMs, items, status)=>{
    const id = state.nextOrderId++;
    state.orders[id] = { id, tableId, server, guests, type:'dine-in', status:status||'open',
      items, openedAt: Date.now()-openedAgoMs, discount:0, tip:0 };
    if(tableId){ getTable(tableId).status = status==='check'?'check':'occupied'; getTable(tableId).orderId = id; }
    return id;
  };

  mk(3,'James Chen',4, 38*60000, [
    buildOrderItem(9,2,[{group:'temp',choice:'Medium'},{group:'addons',choices:['Bacon','Extra Cheese']},{group:'bread',choice:'Brioche Bun'},{group:'side',choice:'French Fries'}],'','fired', 9*60000),
    buildOrderItem(10,1,[{group:'spice',choice:'Medium'},{group:'side',choice:'Side Salad'}],'no pickles','fired', 13*60000),
    buildOrderItem(25,4,[],'','served'),
    buildOrderItem(2,1,[{group:'addons',choices:['Extra Cheese']}],'','ready', 15*60000),
  ]);

  mk(5,'Aisha Patel',6, 58*60000, [
    buildOrderItem(14,2,[{group:'temp',choice:'Medium Rare'},{group:'side',choice:'Mashed Potatoes'}],'','served'),
    buildOrderItem(13,1,[{group:'side',choice:'Sauteed Vegetables'}],'','served'),
    buildOrderItem(16,1,[],'','served'),
    buildOrderItem(6,2,[{group:'dressing',choice:'Caesar'}],'','served'),
    buildOrderItem(31,3,[],'','served'),
    buildOrderItem(23,2,[],'','served'),
  ], 'check');

  mk(7,'James Chen',2, 11*60000, [
    buildOrderItem(18,1,[{group:'pizzaSize',choice:'14" Medium'}],'','new'),
    buildOrderItem(31,2,[],'','fired', 4*60000),
  ]);

  mk(12,'Diego Ruiz',2, 7*60000, [
    buildOrderItem(12,1,[{group:'side',choice:'Side Salad'},{group:'bread',choice:'Multigrain'}],'','fired', 2*60000),
    buildOrderItem(27,2,[],'','served'),
  ]);

  // Online orders — one per major channel, so the login screen can show
  // a live "Online Orders" rail across delivery platforms + the website.
  const onlineId = state.nextOrderId++;
  state.orders[onlineId] = {
    id:onlineId, tableId:null, server:'Online', guests:1, type:'takeout', status:'open',
    platform:'doordash', customerName:'Noah Davis', phone:'(206) 555-0177',
    items:[
      buildOrderItem(19,1,[{group:'pizzaSize',choice:'18" Large'}],'','fired', 11*60000),
      buildOrderItem(25,2,[],'','fired', 11*60000),
    ],
    openedAt: Date.now()-9*60000, discount:0, tip:0,
  };

  const grubhubId = state.nextOrderId++;
  state.orders[grubhubId] = {
    id:grubhubId, tableId:null, server:'Online', guests:1, type:'takeout', status:'open',
    platform:'grubhub', customerName:'Olivia Bennett', phone:'(206) 555-0199',
    items:[
      buildOrderItem(12,1,[{group:'side',choice:'Side Salad'},{group:'bread',choice:'Multigrain'}],'','new'),
      buildOrderItem(27,1,[],'','new'),
    ],
    openedAt: Date.now()-4*60000, discount:0, tip:0,
  };

  const uberEatsId = state.nextOrderId++;
  state.orders[uberEatsId] = {
    id:uberEatsId, tableId:null, server:'Online', guests:1, type:'takeout', status:'open',
    platform:'ubereats', customerName:'Marcus Lee', phone:'(206) 555-0163',
    items:[
      buildOrderItem(18,1,[{group:'pizzaSize',choice:'14" Medium'}],'','fired', 2*60000),
      buildOrderItem(23,1,[],'','fired', 2*60000),
    ],
    openedAt: Date.now()-2*60000, discount:0, tip:0,
  };

  const websiteId = state.nextOrderId++;
  state.orders[websiteId] = {
    id:websiteId, tableId:null, server:'Online', guests:1, type:'takeout', status:'open',
    platform:'website', customerName:'Sofia Martinez', phone:'(206) 555-0124',
    items:[
      buildOrderItem(6,1,[{group:'dressing',choice:'Caesar'}],'','new'),
      buildOrderItem(16,1,[],'','new'),
      buildOrderItem(26,1,[],'','new'),
    ],
    openedAt: Date.now()-1*60000, discount:0, tip:0,
  };

  // mark table 9 as dirty (needs bussing)
  getTable(9).status='dirty';
}

/* ---- Seed: completed order history (for dashboard / reports) ---- */



function seededRandom(seed){
  let s = seed;
  return function(){
    s |= 0; s = s + 0x6D2B79F5 | 0;
    let t = Math.imul(s ^ s >>> 15, 1 | s);
    t = t + Math.imul(t ^ t >>> 7, 61 | t) ^ t;
    return ((t ^ t >>> 14) >>> 0) / 4294967296;
  };
}



function seedCompletedOrders(completedState){
  state = completedState;
  const rnd = seededRandom(20260613);
  const pick = arr => arr[Math.floor(rnd()*arr.length)];
  const availItems = state.menu.items.filter(m=>m.available);
  const serverPool = state.staff.filter(s=>s.role==='Server'||s.role==='Bartender');
  const now = new Date();
  const out = [];
  for(let dayOffset=6; dayOffset>=0; dayOffset--){
    const day = new Date(now); day.setHours(0,0,0,0); day.setDate(now.getDate()-dayOffset);
    const isToday = dayOffset===0;
    const lastHour = isToday ? now.getHours() : 22;
    const orderCount = 22 + Math.floor(rnd()*12);
    for(let i=0;i<orderCount;i++){
      const hour = 11 + Math.floor(rnd()*12); // 11..22
      if(hour>lastHour) continue;
      const minute = Math.floor(rnd()*60);
      const ts = new Date(day); ts.setHours(hour, minute, 0, 0);
      if(ts.getTime() > now.getTime()) continue;
      const numItems = 1 + Math.floor(rnd()*4);
      let subtotal = 0; const items = [];
      for(let j=0;j<numItems;j++){
        const mi = pick(availItems);
        const qty = 1 + (rnd()<0.22?1:0);
        subtotal += mi.price*qty;
        items.push({name:mi.name, category:mi.category, qty, price:mi.price});
      }
      const tax = subtotal*state.restaurant.taxRate;
      const tip = subtotal*(0.15+rnd()*0.12);
      const total = subtotal+tax+tip;
      const isCard = rnd()<0.74;
      out.push({
        id: 9000+out.length,
        ts: ts.getTime(),
        items, subtotal, tax, tip, total,
        paymentMethod: isCard?'card':'cash',
        server: pick(serverPool).name,
        // ---- back-office fields ----
        status:'completed',          // completed | partially_refunded | refunded | voided
        refunds:[],                  // [{id, amount, reason, method, ts, by, settled}]
        customerId: rnd()<0.25 ? (1+Math.floor(rnd()*state.customers.length)) : null,
        settled: isCard ? !isToday : null,  // cash never settles; card: past days settled below
        batchId: null,               // set when a settlement batch closes
      });
    }
  }
  out.sort((a,b)=>a.ts-b.ts);

  // Close one settlement batch per past day (card transactions only),
  // mirroring a real end-of-night batch close at the card processor.
  const batches = [];
  let batchNo = 1;
  for(let dayOffset=6; dayOffset>=1; dayOffset--){
    const day = new Date(now); day.setHours(0,0,0,0); day.setDate(now.getDate()-dayOffset);
    const dayEnd = new Date(day); dayEnd.setHours(23,15,0,0);
    const txns = out.filter(o=>o.paymentMethod==='card' && o.ts>=day.getTime() && o.ts<day.getTime()+86400000);
    if(!txns.length) continue;
    const batchId = 100+batchNo++;
    txns.forEach(t=>{ t.settled=true; t.batchId=batchId; });
    batches.push({
      id:batchId,
      closedAt:dayEnd.getTime(),
      closedBy:'Maria Lopez',
      transactionIds:txns.map(t=>t.id),
      count:txns.length,
      gross:txns.reduce((s,t)=>s+t.total,0),
      tips:txns.reduce((s,t)=>s+t.tip,0),
      refunds:0,
      net:txns.reduce((s,t)=>s+t.total,0),
    });
  }
  // Today's card transactions stay unsettled (the open batch).
  out.filter(o=>o.paymentMethod==='card' && o.settled!==true).forEach(o=>{ o.settled=false; });
  state.settlementBatches = batches;
  state.completedOrders = out;
}



function buildSeedState(){
  const state = JSON.parse(JSON.stringify(seedState));
  // restore Date.now()-based notification timestamps (JSON round trip keeps numbers fine, but
  // re-evaluate so a freshly generated db.json has "fresh" relative times)
  state.notifications = [
    {id:1, text:'Low stock alert: Salmon Fillet below par level', time:Date.now()-1000*60*22, type:'warning'},
    {id:2, text:'Online order #1049 received — Takeout', time:Date.now()-1000*60*9, type:'info'},
    {id:3, text:'Table 7 check has been open for 55 minutes', time:Date.now()-1000*60*3, type:'warning'},
  ];
  state.staff.forEach(s=>{ if(s.clockedIn) s.clockInTime = Date.now() - (Date.now() - s.clockInTime); });
  seedActiveOrders(state);
  seedCompletedOrders(state);
  return state;
}

module.exports = { buildSeedState };
