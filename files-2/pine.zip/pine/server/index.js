/**
 * Pine POS — backend server
 * --------------------------------------------------------------
 * Single source of truth for the POS Terminal, Handheld, and KDS
 * frontends. Persists to a JSON file on disk and broadcasts every
 * change to all connected clients in real time via Socket.io.
 *
 * Run:  npm start   (defaults to http://localhost:4000)
 */
const path = require('path');
const fs = require('fs');
const http = require('http');
const express = require('express');
const { Server } = require('socket.io');
const { buildSeedState } = require('./seed');

const PORT = process.env.PORT || 4000;
const DB_FILE = path.join(__dirname, 'data', 'db.json');

/* ----------------------------------------------------------------
   Keys that are shared across every device (table state, orders,
   menu, staff, etc). Anything NOT in this list (currentStaff, view,
   viewParams, ...) is considered per-device/session state and is
   never persisted or broadcast by the server.
   ---------------------------------------------------------------- */
const SHARED_KEYS = [
  'restaurant', 'staff', 'menu', 'modifierGroups', 'tables', 'orders',
  'completedOrders', 'inventory', 'customers', 'tipOuts', 'notifications',
  'giftCards', 'vouchers', 'settlementBatches',
  'nextUid', 'nextOrderId',
];

function pickShared(obj) {
  const out = {};
  SHARED_KEYS.forEach(k => { if (obj[k] !== undefined) out[k] = obj[k]; });
  return out;
}

/* ----------------------------------------------------------------
   Load state from disk, or build it fresh from seed data the first
   time the server runs.
   ---------------------------------------------------------------- */
function loadState() {
  try {
    const raw = fs.readFileSync(DB_FILE, 'utf8');
    const data = JSON.parse(raw);
    console.log(`[db] loaded state from ${DB_FILE}`);
    return pickShared(data);
  } catch (err) {
    console.log('[db] no existing database found — seeding fresh data');
    const seeded = pickShared(buildSeedState());
    fs.mkdirSync(path.dirname(DB_FILE), { recursive: true });
    fs.writeFileSync(DB_FILE, JSON.stringify(seeded, null, 2));
    return seeded;
  }
}

let state = loadState();

let saveTimer = null;
function persist() {
  if (saveTimer) clearTimeout(saveTimer);
  saveTimer = setTimeout(() => {
    fs.writeFileSync(DB_FILE, JSON.stringify(state, null, 2));
    saveTimer = null;
  }, 400);
}

/* ----------------------------------------------------------------
   App + HTTP + Socket.io
   ---------------------------------------------------------------- */
const app = express();
app.use(express.json({ limit: '5mb' }));

const server = http.createServer(app);
const io = new Server(server, { cors: { origin: '*' } });

/* ----- REST API ----- */

// Full shared state — used by every frontend on initial load.
app.get('/api/state', (req, res) => {
  res.json(state);
});

// Health check (also doubles as a "is the backend really connected" demo endpoint)
app.get('/api/health', (req, res) => {
  res.json({
    ok: true,
    time: Date.now(),
    connectedClients: io.engine.clientsCount,
    restaurant: state.restaurant.name,
  });
});

// PIN-based staff login. Returns the staff record (sans pin) and clocks
// the person in if they weren't already. This is the only "auth" Pine POS
// needs for a demo — every device shares one restaurant-wide session.
app.post('/api/login', (req, res) => {
  const { pin } = req.body || {};
  const staffMember = state.staff.find(s => s.pin === String(pin || ''));
  if (!staffMember) return res.status(401).json({ error: 'Invalid PIN' });

  if (!staffMember.clockedIn) {
    staffMember.clockedIn = true;
    staffMember.clockInTime = Date.now();
    persist();
    io.emit('state:update', pickShared(state));
  }

  const { pin: _pin, ...safe } = staffMember;
  res.json({ staff: safe });
});

/* ================================================================
   BACK OFFICE REST API
   Customers, transactions (refund / void / edit), gift cards,
   vouchers, and batch settlements. Every mutation persists to disk
   and broadcasts to all connected POS / Handheld / KDS clients so
   the UI updates in real time — the same sync channel the
   frontends already use.
   ================================================================ */
function commit(res, payload) {
  persist();
  io.emit('state:update', pickShared(state));
  res.json(payload);
}
const round2 = n => Math.round(n * 100) / 100;
const nextUid = () => state.nextUid++;

/* ---------------- Customers ---------------- */
app.get('/api/customers', (req, res) => {
  const q = (req.query.q || '').toLowerCase();
  let list = state.customers;
  if (q) list = list.filter(c =>
    c.name.toLowerCase().includes(q) ||
    (c.email || '').toLowerCase().includes(q) ||
    (c.phone || '').includes(q));
  res.json(list);
});

app.get('/api/customers/:id', (req, res) => {
  const c = state.customers.find(x => x.id === Number(req.params.id));
  if (!c) return res.status(404).json({ error: 'Customer not found' });
  const orders = state.completedOrders.filter(o => o.customerId === c.id);
  res.json({ ...c, orders });
});

app.post('/api/customers', (req, res) => {
  const { name, phone = '', email = '', address = '' } = req.body || {};
  if (!name || !name.trim()) return res.status(400).json({ error: 'name is required' });
  const customer = {
    id: nextUid(), name: name.trim(), phone, email, address,
    visits: 0, points: 0, totalSpent: 0,
    since: new Date().toISOString().slice(0, 10),
  };
  state.customers.push(customer);
  commit(res, customer);
});

app.put('/api/customers/:id', (req, res) => {
  const c = state.customers.find(x => x.id === Number(req.params.id));
  if (!c) return res.status(404).json({ error: 'Customer not found' });
  const allowed = ['name', 'phone', 'email', 'address', 'visits', 'points', 'totalSpent'];
  allowed.forEach(k => { if (req.body[k] !== undefined) c[k] = req.body[k]; });
  commit(res, c);
});

app.delete('/api/customers/:id', (req, res) => {
  const idx = state.customers.findIndex(x => x.id === Number(req.params.id));
  if (idx === -1) return res.status(404).json({ error: 'Customer not found' });
  const [removed] = state.customers.splice(idx, 1);
  // Detach from transactions rather than orphaning references
  state.completedOrders.forEach(o => { if (o.customerId === removed.id) o.customerId = null; });
  commit(res, { deleted: removed.id });
});

/* ---------------- Transactions ---------------- */
function findTxn(id) { return state.completedOrders.find(o => o.id === Number(id)); }
function refundedTotal(t) { return (t.refunds || []).reduce((s, r) => s + r.amount, 0); }

app.get('/api/transactions', (req, res) => {
  let list = [...state.completedOrders];
  const { from, to, method, status, server, customerId, settled } = req.query;
  if (from) list = list.filter(o => o.ts >= Number(from));
  if (to) list = list.filter(o => o.ts <= Number(to));
  if (method) list = list.filter(o => o.paymentMethod === method);
  if (status) list = list.filter(o => (o.status || 'completed') === status);
  if (server) list = list.filter(o => o.server === server);
  if (customerId) list = list.filter(o => o.customerId === Number(customerId));
  if (settled !== undefined) list = list.filter(o => String(o.settled) === settled);
  list.sort((a, b) => b.ts - a.ts);
  res.json(list);
});

app.get('/api/transactions/:id', (req, res) => {
  const t = findTxn(req.params.id);
  if (!t) return res.status(404).json({ error: 'Transaction not found' });
  res.json(t);
});

// Edit a transaction: adjust tip, payment method, or attached customer.
// Tip/method edits are only allowed before the transaction settles —
// after batch close the processor already has the money.
app.put('/api/transactions/:id', (req, res) => {
  const t = findTxn(req.params.id);
  if (!t) return res.status(404).json({ error: 'Transaction not found' });
  if (t.status === 'voided') return res.status(400).json({ error: 'Cannot edit a voided transaction' });
  const { tip, paymentMethod, customerId, editedBy } = req.body || {};

  if (tip !== undefined || paymentMethod !== undefined) {
    if (t.paymentMethod === 'card' && t.settled) {
      return res.status(400).json({ error: 'Transaction already settled — tip/method can no longer change' });
    }
    if (tip !== undefined) {
      const newTip = round2(Number(tip));
      if (isNaN(newTip) || newTip < 0) return res.status(400).json({ error: 'Invalid tip' });
      t.total = round2(t.total - t.tip + newTip);
      t.tip = newTip;
    }
    if (paymentMethod !== undefined) {
      if (!['card', 'cash', 'giftcard'].includes(paymentMethod)) return res.status(400).json({ error: 'Invalid payment method' });
      t.paymentMethod = paymentMethod;
      t.settled = paymentMethod === 'card' ? false : null;
    }
  }
  if (customerId !== undefined) t.customerId = customerId === null ? null : Number(customerId);
  t.editedAt = Date.now();
  if (editedBy) t.editedBy = editedBy;
  commit(res, t);
});

// Refund — full or partial. Refund of an already-settled card
// transaction is tracked unsettled and nets against the next batch.
app.post('/api/transactions/:id/refund', (req, res) => {
  const t = findTxn(req.params.id);
  if (!t) return res.status(404).json({ error: 'Transaction not found' });
  if (t.status === 'voided') return res.status(400).json({ error: 'Transaction is voided' });
  const amount = round2(Number((req.body || {}).amount));
  const { reason = '', by = 'Back Office', method } = req.body || {};
  const remaining = round2(t.total - refundedTotal(t));
  if (isNaN(amount) || amount <= 0) return res.status(400).json({ error: 'Invalid amount' });
  if (amount > remaining + 0.001) return res.status(400).json({ error: `Amount exceeds refundable balance (${remaining.toFixed(2)})` });

  const refund = {
    id: nextUid(), amount, reason, by, ts: Date.now(),
    method: method || t.paymentMethod,
    settled: t.paymentMethod === 'card' ? false : null,
  };
  t.refunds = t.refunds || [];
  t.refunds.push(refund);
  t.status = refundedTotal(t) >= t.total - 0.001 ? 'refunded' : 'partially_refunded';
  commit(res, t);
});

// Void — wipes the transaction as if it never happened. Only allowed
// before settlement; after that money has moved and it must be a refund.
app.post('/api/transactions/:id/void', (req, res) => {
  const t = findTxn(req.params.id);
  if (!t) return res.status(404).json({ error: 'Transaction not found' });
  if (t.status === 'voided') return res.status(400).json({ error: 'Already voided' });
  if (t.paymentMethod === 'card' && t.settled) {
    return res.status(400).json({ error: 'Already settled — use a refund instead of a void' });
  }
  t.status = 'voided';
  t.voidedAt = Date.now();
  t.voidReason = (req.body || {}).reason || '';
  t.voidedBy = (req.body || {}).by || 'Back Office';
  commit(res, t);
});

/* ---------------- Gift cards ---------------- */
function makeCode(prefix) {
  const chars = 'ABCDEFGHJKMNPQRSTUVWXYZ23456789';
  const seg = n => Array.from({ length: n }, () => chars[Math.floor(Math.random() * chars.length)]).join('');
  return `${prefix}-${seg(4)}-${seg(4)}`;
}

app.get('/api/giftcards', (req, res) => res.json(state.giftCards || []));

app.post('/api/giftcards', (req, res) => {
  const amount = round2(Number((req.body || {}).amount));
  const { customerId = null, issuedBy = 'Back Office', note = '' } = req.body || {};
  if (isNaN(amount) || amount <= 0) return res.status(400).json({ error: 'Invalid amount' });
  const card = {
    id: nextUid(), code: makeCode('GC'), initialAmount: amount, balance: amount,
    customerId: customerId ? Number(customerId) : null, issuedBy, note,
    ts: Date.now(), active: true,
    history: [{ type: 'issue', amount, ts: Date.now(), by: issuedBy }],
  };
  state.giftCards = state.giftCards || [];
  state.giftCards.push(card);
  commit(res, card);
});

app.post('/api/giftcards/:code/redeem', (req, res) => {
  const card = (state.giftCards || []).find(c => c.code === req.params.code && c.active);
  if (!card) return res.status(404).json({ error: 'Gift card not found or inactive' });
  const amount = round2(Number((req.body || {}).amount));
  if (isNaN(amount) || amount <= 0) return res.status(400).json({ error: 'Invalid amount' });
  if (amount > card.balance + 0.001) return res.status(400).json({ error: `Insufficient balance (${card.balance.toFixed(2)})` });
  card.balance = round2(card.balance - amount);
  card.history.push({ type: 'redeem', amount: -amount, ts: Date.now(), note: (req.body || {}).note || '' });
  commit(res, card);
});

app.post('/api/giftcards/:code/deactivate', (req, res) => {
  const card = (state.giftCards || []).find(c => c.code === req.params.code);
  if (!card) return res.status(404).json({ error: 'Gift card not found' });
  card.active = false;
  card.history.push({ type: 'deactivate', amount: 0, ts: Date.now(), by: (req.body || {}).by || 'Back Office' });
  commit(res, card);
});

/* ---------------- Vouchers ---------------- */
app.get('/api/vouchers', (req, res) => res.json(state.vouchers || []));

// "Send" a voucher — creates the code and records the (simulated) email send.
app.post('/api/vouchers', (req, res) => {
  const amount = round2(Number((req.body || {}).amount));
  const { customerId = null, sentTo, sentBy = 'Back Office', note = '' } = req.body || {};
  if (isNaN(amount) || amount <= 0) return res.status(400).json({ error: 'Invalid amount' });
  if (!sentTo) return res.status(400).json({ error: 'sentTo (email) is required' });
  const voucher = {
    id: nextUid(), code: makeCode('VCH'), amount,
    customerId: customerId ? Number(customerId) : null,
    sentTo, sentBy, note, ts: Date.now(), redeemed: false,
  };
  state.vouchers = state.vouchers || [];
  state.vouchers.push(voucher);
  console.log(`[voucher] ${voucher.code} ($${amount}) sent to ${sentTo}`);
  commit(res, voucher);
});

app.post('/api/vouchers/:code/redeem', (req, res) => {
  const v = (state.vouchers || []).find(x => x.code === req.params.code);
  if (!v) return res.status(404).json({ error: 'Voucher not found' });
  if (v.redeemed) return res.status(400).json({ error: 'Voucher already redeemed' });
  v.redeemed = true;
  v.redeemedAt = Date.now();
  v.redeemedNote = (req.body || {}).note || '';
  commit(res, v);
});

/* ---------------- Batch settlements ---------------- */
function openBatchItems() {
  const txns = state.completedOrders.filter(o =>
    o.paymentMethod === 'card' && o.settled === false && o.status !== 'voided');
  const refunds = [];
  state.completedOrders.forEach(o => (o.refunds || []).forEach(r => {
    if (r.method === 'card' && r.settled === false) refunds.push({ txnId: o.id, ...r });
  }));
  return { txns, refunds };
}

app.get('/api/settlements', (req, res) => {
  const { txns, refunds } = openBatchItems();
  res.json({
    open: {
      count: txns.length,
      gross: round2(txns.reduce((s, t) => s + t.total, 0)),
      tips: round2(txns.reduce((s, t) => s + t.tip, 0)),
      refunds: round2(refunds.reduce((s, r) => s + r.amount, 0)),
      net: round2(txns.reduce((s, t) => s + t.total, 0) - refunds.reduce((s, r) => s + r.amount, 0)),
    },
    batches: [...(state.settlementBatches || [])].sort((a, b) => b.closedAt - a.closedAt),
  });
});

app.post('/api/settlements/close', (req, res) => {
  const { txns, refunds } = openBatchItems();
  if (!txns.length && !refunds.length) return res.status(400).json({ error: 'Nothing to settle' });
  const batch = {
    id: nextUid(),
    closedAt: Date.now(),
    closedBy: (req.body || {}).by || 'Back Office',
    transactionIds: txns.map(t => t.id),
    count: txns.length,
    gross: round2(txns.reduce((s, t) => s + t.total, 0)),
    tips: round2(txns.reduce((s, t) => s + t.tip, 0)),
    refunds: round2(refunds.reduce((s, r) => s + r.amount, 0)),
    net: round2(txns.reduce((s, t) => s + t.total, 0) - refunds.reduce((s, r) => s + r.amount, 0)),
  };
  txns.forEach(t => { t.settled = true; t.batchId = batch.id; });
  state.completedOrders.forEach(o => (o.refunds || []).forEach(r => {
    if (r.method === 'card' && r.settled === false) { r.settled = true; r.batchId = batch.id; }
  }));
  state.settlementBatches = state.settlementBatches || [];
  state.settlementBatches.push(batch);
  commit(res, batch);
});

/* ----- Real-time sync ----- */
io.on('connection', (socket) => {
  console.log(`[socket] client connected (${socket.id}) — total ${io.engine.clientsCount}`);

  // Send the current canonical state immediately so a freshly-connected
  // client (e.g. a KDS that just powered on) is in sync before it even
  // makes its first REST call.
  socket.emit('state:update', state);

  // A client made a change. Merge the shared slices into canonical
  // state, persist, and broadcast to everyone else.
  socket.on('state:update', (incoming) => {
    if (!incoming || typeof incoming !== 'object') return;
    const shared = pickShared(incoming);
    Object.assign(state, shared);
    persist();
    socket.broadcast.emit('state:update', shared);
  });

  socket.on('disconnect', () => {
    console.log(`[socket] client disconnected (${socket.id}) — total ${io.engine.clientsCount}`);
  });
});

/* ----- Static frontends ----- */
app.use('/shared', express.static(path.join(__dirname, '..', 'public', 'shared')));
app.use('/pos', express.static(path.join(__dirname, '..', 'public', 'pos')));
app.use('/handheld', express.static(path.join(__dirname, '..', 'public', 'handheld')));
app.use('/kds', express.static(path.join(__dirname, '..', 'public', 'kds')));

app.get('/', (req, res) => res.redirect('/pos'));

server.listen(PORT, () => {
  console.log(`\nPine POS backend running at http://localhost:${PORT}`);
  console.log(`  POS Terminal: http://localhost:${PORT}/pos`);
  console.log(`  Handheld:     http://localhost:${PORT}/handheld`);
  console.log(`  KDS:          http://localhost:${PORT}/kds`);
  console.log(`  API:          http://localhost:${PORT}/api/state\n`);
});
