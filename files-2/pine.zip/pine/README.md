# Pine — Restaurant Platform (POS · Handheld · KDS)

A full-stack restaurant operating system: one Node/Express + Socket.io
backend that keeps a **POS terminal**, **handheld**, and **Kitchen Display
System (KDS)** in perfect real-time sync. Fire an order from a handheld and
watch it land on the kitchen screen instantly; bump a ticket in the kitchen
and the POS terminal updates the same second — no refresh, anywhere.

---

## 1. Quick start

```bash
npm install
npm start
```

The server starts on **http://localhost:4000** (set `PORT` to change it) and
prints links to every frontend:

| Frontend | URL | Designed for |
|---|---|---|
| **POS Terminal** | `/pos` | Front-of-house counter / register, large screen |
| **Handheld** | `/handheld` | Phones & tablets — servers and bartenders on the floor |
| **Kitchen Display (KDS)** | `/kds` | Large TV/monitor mounted in the kitchen |
| **API** | `/api/state`, `/api/health`, `/api/login` | Backend data + health check |

The first time it runs, the server seeds itself with a realistic dataset for
**The Riverside Bistro**: 8 staff, a 32-item menu across 8 categories, a
17-table floor plan, 15 inventory items, 7 guest profiles, 5 open
orders/tickets, and ~185 historical orders spanning the last 7 days (so
dashboards and reports have real numbers on day one).

To wipe the database and reseed fresh data, stop the server and delete
`server/data/db.json` (or the whole `server/data/` folder), then `npm start`
again.

### Login PINs (for the demo)

| Name | Role | PIN |
|---|---|---|
| Maria Lopez | Manager | `1234` |
| James Chen | Server | `2222` |
| Aisha Patel | Server | `3333` |
| Tom Reilly | Cook | `4444` |
| Sara Kim | Host | `5555` |
| Diego Ruiz | Bartender | `6666` |
| Priya Nair | Server | `7777` |
| Owen Brooks | Cook | `8888` |

---

## 2. Demoing real-time sync (the "wow" moment)

Open three browser windows side by side (or three real devices on the same
Wi-Fi, pointing at `http://<your-computer's-LAN-IP>:4000/...`):

1. **KDS** (`/kds`) on a big screen.
2. **Handheld** (`/handheld`) — log in as Aisha Patel (`3333`).
3. **POS Terminal** (`/pos`) — log in as Maria Lopez (`1234`).

Now:

- On the **handheld**, seat a table → add a few menu items (try one with
  modifiers, like a **Classic Burger**) → "Send to Kitchen". The ticket
  appears on the **KDS** within ~150ms, with a flash animation, a toast
  ("New ticket #…"), and an audible alert tone (tap the bell icon on the KDS
  once first to enable sound — browsers require a tap before audio can play).
- On the **KDS**, tap **Ready** on an item, then **Bump All & Serve**. The
  **POS** and **handheld** ticket views update the item status
  (`FIRED` → `SERVED`) live, and the kitchen ticket counters in every
  sidebar/nav update too.
- Open **Tables** on any device — table status (Available / Occupied /
  Check / Needs Bussing) is shared across all three frontends.
- Clock someone in/out, adjust inventory, edit the menu, or add a guest on
  the POS — it's reflected everywhere instantly.

Every connected device also shows a small **● Live** badge — it turns red
("Offline") if the connection drops, and reconnects automatically.

---

## 3. Architecture

```
pine/
├── server/
│   ├── index.js     ← Express + Socket.io server, REST API, persistence
│   ├── seed.js       ← Seed data + data-model helpers (ported from the
│   │                    original single-file prototype)
│   └── data/
│       └── db.json   ← Canonical state, persisted to disk (auto-created)
├── public/
│   ├── shared/
│   │   ├── sync.js    ← PineSync — the real-time sync client used by all 3 apps
│   │   ├── theme.css   ← Shared "Ember & Mint" design tokens / components
│   │   └── icons.js    ← Shared SVG icon set
│   ├── pos/index.html      ← POS Terminal (full app, 11 views)
│   ├── handheld/index.html ← Handheld (mobile-first, bottom-nav)
│   └── kds/index.html      ← Kitchen Display (large-screen ticket board)
└── package.json
```

### How the sync works

The server holds one canonical JSON document — the entire restaurant's live
state (tables, orders, menu, staff, inventory, guests, tip-outs,
notifications, etc.) — and persists it to `server/data/db.json` on every
change (debounced 400ms).

Each frontend keeps a local copy of that same shape, plus a few
**session-only** fields that never leave the device (`currentStaff`, `view`,
`viewParams` — i.e. "what is *this* terminal currently looking at, and who's
logged into it").

1. **On load**, every frontend calls `GET /api/state` to get the current
   canonical state.
2. **On every user action** (place an order, bump a ticket, edit a menu
   item, clock in/out, …) the frontend updates its local state immediately
   (so the UI never feels laggy), then calls `PineSync.push(state)`, which
   emits the *shared* slice of state over a Socket.io connection, debounced
   ~150ms.
3. The **server** merges the incoming slice into its canonical state,
   persists it, and broadcasts it to every *other* connected client via
   `socket.broadcast.emit('state:update', …)`.
4. Every other frontend merges that update into its local state and
   re-renders — typically within a few hundred milliseconds.

This "whole shared-state slice, debounced" approach is intentionally simple:
for a single-location demo it's fast and trivially consistent. The
[Next steps](#5-next-steps--beyond-the-mvp) section below covers how this
would evolve for production scale.

### REST API

| Method | Path | Purpose |
|---|---|---|
| `GET` | `/api/state` | Full canonical shared state (used on initial load) |
| `GET` | `/api/health` | Liveness check + connected-client count |
| `POST` | `/api/login` | `{ pin }` → staff record, clocks the person in |

Real-time mutation sync happens over Socket.io (`state:update`), not REST —
see above.

---

## 4. What's in each frontend

### POS Terminal (`/pos`)
The full back-office + front-of-house app: Dashboard, My Sales, Tables
(floor plan), Order entry (menu grid, modifiers, tickets, split checks,
payments), Kitchen view, Menu management, Inventory, Staff & role-based
permissions, Reports, Guests/CRM, and Settings. Role-based navigation means
servers/cooks/hosts land on a personal "My Sales" view instead of the
manager dashboard, and can't see inventory, payroll, or settings.

### Handheld (`/handheld`)
A mobile-first companion for servers and bartenders: bottom tab bar
(Tables → Order → Kitchen → My Sales), table seating, full menu + modifier
sheets, cart with live totals, "Send to Kitchen", a payment sheet (split
evenly or one check, tip presets, card/cash), a kitchen ticket view, and a
clock-out flow with department sales breakdown and peer-to-peer tip-outs.

### Kitchen Display (`/kds`)
A dedicated, large-screen ticket board: station tabs with live ticket
counts (All / Cold Line / Grill / Pizza Oven / Pastry / Bar), urgency-colored
tickets (green → amber at 8 min → red at 12 min), per-item "Ready" bumps and
"Bump All & Serve", a toggleable audio alert + flash animation for brand-new
tickets, and a live connection badge.

---

## 5. Next steps — beyond the MVP

This is a genuine, runnable full-stack app — but it's scoped as a
**local-network MVP** so it can be demoed today. Taking it to a multi-location,
investor-grade SaaS product would mean:

- **Diff-based sync** instead of pushing the full shared-state slice on every
  change — send only the changed records (smaller payloads, scales to many
  concurrent devices/locations).
- **Server-side ID generation** for new orders/line-items (currently
  `nextOrderId`/`nextUid` counters live in shared state — fine for a single
  location with sequential demo actions, but two devices creating an order in
  the same instant could theoretically collide before they sync).
- **A real database** (Postgres/managed SQL) instead of a JSON file, with
  proper transactions, audit trails, and backups.
- **Payments**: integrate Stripe Terminal / Stripe Connect for real card
  processing, instead of the simulated "Charge $X" button.
- **Accounts & multi-location auth**: real user accounts (not just PINs),
  org/location hierarchy, and role-based access enforced server-side (today
  it's enforced in the frontend, which is fine for a single shared
  terminal/restaurant but not for a multi-tenant product).
- **Cloud hosting** with HTTPS, horizontal scaling, and a CDN — including
  normal access to Google Fonts (in this sandboxed dev environment,
  `fonts.googleapis.com` is blocked by the network allowlist, so the UI falls
  back to system fonts; that resolves automatically with normal internet
  access).
- **Notifications**: push notifications to handhelds (e.g. "Table 5's food is
  up") instead of in-app toasts only.

---

## 6. Also included

The original **standalone, single-file** version of the POS
(`index.html` — works fully offline with simulated data, no backend
required) is still available if you want a no-install, drag-and-drop demo on
a single device.
