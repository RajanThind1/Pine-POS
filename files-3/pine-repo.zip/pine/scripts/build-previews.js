#!/usr/bin/env node
/**
 * Regenerates public/{pos,handheld,kds}/preview.html from the live
 * index.html files by inlining theme.css, icons.js, seed state, and
 * a no-op PineSync stub — so each preview is always a true mirror of
 * the live app, just runnable without the Node server.
 */
const fs = require('fs');
const path = require('path');
const ROOT = path.join(__dirname, '..');
const { buildSeedState } = require(path.join(ROOT, 'server', 'seed'));

const theme = fs.readFileSync(path.join(ROOT, 'public', 'shared', 'theme.css'), 'utf8');
const icons = fs.readFileSync(path.join(ROOT, 'public', 'shared', 'icons.js'), 'utf8');
const qrlib = fs.readFileSync(path.join(ROOT, 'public', 'shared', 'qr.js'), 'utf8');
const seed = JSON.stringify(buildSeedState());

const stubSync = `
window.__SEED_STATE__ = ${seed};
window.PineSync = {
  SHARED_KEYS: ['restaurant','staff','menu','modifierGroups','tables','orders','completedOrders','inventory','customers','tipOuts','notifications','giftCards','vouchers','settlementBatches','nextUid','nextOrderId'],
  async loadState() { return window.__SEED_STATE__; },
  connect(onUpdate, opts={}) { if(opts.onConnect) setTimeout(opts.onConnect, 50); return null; },
  push(fullState) { /* no-op in standalone preview */ },
  merge(localState, shared) { Object.assign(localState, shared); if(localState.currentStaff){ const fresh = localState.staff.find(s=>s.id===localState.currentStaff.id); if(fresh) localState.currentStaff = fresh; } },
  connected: true,
};
`;

const apps = ['pos', 'handheld', 'kds', 'guest'];
for (const app of apps) {
  const srcPath = path.join(ROOT, 'public', app, 'index.html');
  if (!fs.existsSync(srcPath)) continue;
  let html = fs.readFileSync(srcPath, 'utf8');

  html = html.replace(
    '<link rel="stylesheet" href="/shared/theme.css">',
    () => `<style>\n${theme}\n</style>`
  );
  html = html.replace(
    '<script src="/shared/icons.js"></script>',
    () => `<script>\n${icons}\n</script>`
  );
  html = html.replace(
    '<script src="/shared/qr.js"></script>',
    () => `<script>\n${qrlib}\n</script>`
  );
  html = html.replace(
    '<script src="/socket.io/socket.io.js"></script>\n<script src="/shared/sync.js"></script>',
    () => `<script>${stubSync}</script>`
  );

  const outPath = path.join(ROOT, 'public', app, 'preview.html');
  fs.writeFileSync(outPath, html);
  console.log(`built ${app}/preview.html (${html.length} bytes)`);
}
